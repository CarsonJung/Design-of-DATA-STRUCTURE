# tvN+

> An electron-vue project
tvN채널에 만약 재방송채널이 생긴다면 어떻게 편성할것인가?

#### Build Setup

``` bash
# approach directory
cd ./tvNPlus

# install dependencies
npm install

# serve with hot reload at localhost:9080
npm run dev

# build electron application for production
npm run build


```

---

This project was generated with [electron-vue](https://github.com/SimulatedGREG/electron-vue)@[9add6ff](https://github.com/SimulatedGREG/electron-vue/tree/9add6ff4d47eaf8fb9f04efd0aca7be4dc6fb69d) using [vue-cli](https://github.com/vuejs/vue-cli). Documentation about the original structure can be found [here](https://simulatedgreg.gitbooks.io/electron-vue/content/index.html).
