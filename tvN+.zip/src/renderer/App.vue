<template>
  <div id="app">
    <router-view></router-view>
  </div>
</template>

<script>
  export default {
    name: 'tv_n_plus'
  }
</script>

<style>
  @import "~bulma/css/bulma.css";
</style>
